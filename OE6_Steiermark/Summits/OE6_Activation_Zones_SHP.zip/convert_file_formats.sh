#!/bin/bash
# execute script within the "../activation_zones/shp/" folder

for file in *.shp; do
    echo $file
    filename="${file%.*}"
    ogr2ogr -f GeoJSON ../geojson/$filename.geojson $file
done
